import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Scale, FileText, Settings, Activity, DollarSign, Users, Home, Plus, 
  BrainCircuit, Zap, AlertTriangle, ArrowRight, Send, ClipboardList, 
  Building2, ShieldAlert, Palette, BarChart, Sparkles, Share2, Video, 
  Briefcase, UploadCloud, Store, Shield, PenTool, Percent, LayoutGrid,
  CheckCircle, XCircle, Info, Download, Copy, MessageSquare, Trash2, Edit, Check
} from 'lucide-react';
import { useAuth } from '../AuthContext';

// Interfaces internas para o simulador e módulo de crédito
interface CreditoLead {
  id: string;
  empresa: string;
  cnpj: string;
  adminNome: string;
  generoAdmin: 'Homem' | 'Mulher';
  faturamentoAnual: number;
  tempoConstituicao: number; // meses
  possuiContabilidade: boolean;
  temDividasBancarias: boolean;
  temDividasImpostos: boolean;
  score: number;
  limiteEstimado: number;
  tier: 'Tier A' | 'Tier B' | 'Inapto';
  status: 'Simulado' | 'Documentação Pendente' | 'Análise Técnica' | 'Aprovado' | 'Pago' | 'Limpeza de Nome Ativada';
  dataSimulacao: string;
  afiliadoId?: string;
  comissaoEstimada?: number;
  regiao: string;
}

interface ComissaoConfig {
  bronzeComissaoDireta: number;
  bronzeOverride: number;
  prataComissaoDireta: number;
  prataOverride: number;
  ouroComissaoDireta: number;
  ouroOverride: number;
}

export default function CreditoInteligenteDashboard() {
  const { profile, isMaster } = useAuth();
  
  // 1. Controle de Perfil para testes (Permite alternar entre as 5 visões)
  const [selectedRole, setSelectedRole] = useState<'MASTER' | 'UNIDADE' | 'ADVOGADO' | 'VENDEDOR' | 'AFILIADO'>('MASTER');

  // Inicializa o perfil padrão de acordo com o usuário logado
  useEffect(() => {
    if (profile?.tipo_usuario) {
      const role = profile.tipo_usuario;
      if (['MASTER', 'ADMIN', 'MasterAdmin', 'AdminGeral'].includes(role)) {
        setSelectedRole('MASTER');
      } else if (['UNIDADE', 'DIRETOR', 'GestorUnidade'].includes(role)) {
        setSelectedRole('UNIDADE');
      } else if (['ADVOGADO'].includes(role)) {
        setSelectedRole('ADVOGADO');
      } else if (['VENDEDOR'].includes(role)) {
        setSelectedRole('VENDEDOR');
      } else {
        setSelectedRole('AFILIADO');
      }
    }
  }, [profile]);

  // 2. Estados da aplicação
  const [leads, setLeads] = useState<CreditoLead[]>([]);
  const [comissaoConfig, setComissaoConfig] = useState<ComissaoConfig>({
    bronzeComissaoDireta: 10,
    bronzeOverride: 0,
    prataComissaoDireta: 15,
    prataOverride: 2,
    ouroComissaoDireta: 20,
    ouroOverride: 5
  });

  // Estado do Simulador Ativo
  const [simEmpresa, setSimEmpresa] = useState('');
  const [simCnpj, setSimCnpj] = useState('');
  const [simAdminNome, setSimAdminNome] = useState('');
  const [simGenero, setSimGenero] = useState<'Homem' | 'Mulher'>('Mulher');
  const [simFaturamento, setSimFaturamento] = useState<number>(500000);
  const [simTempo, setSimTempo] = useState<number>(24);
  const [simContabilidade, setSimContabilidade] = useState<boolean>(true);
  const [simDividasBancarias, setSimDividasBancarias] = useState<boolean>(false);
  const [simDividasImpostos, setSimDividasImpostos] = useState<boolean>(false);
  
  // Estado de feedbacks visuais
  const [copiadoId, setCopiadoId] = useState<string | null>(null);
  const [showReabModal, setShowReabModal] = useState<CreditoLead | null>(null);
  const [showBridgeModal, setShowBridgeModal] = useState<CreditoLead | null>(null);
  const [showSimuladorModal, setShowSimuladorModal] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState('');

  // 3. Carregar dados fictícios/Iniciais e localStorage
  useEffect(() => {
    const savedLeads = localStorage.getItem('gsa_credito_leads');
    const savedConfig = localStorage.getItem('gsa_credito_config');

    if (savedLeads) {
      setLeads(JSON.parse(savedLeads));
    } else {
      // Massa inicial rica para simulação realista
      const defaultLeads: CreditoLead[] = [
        {
          id: 'lead-1',
          empresa: 'Tecnologia Alpha Ltda',
          cnpj: '12.345.678/0001-90',
          adminNome: 'Mariana Medeiros',
          generoAdmin: 'Mulher',
          faturamentoAnual: 1200000,
          tempoConstituicao: 36,
          possuiContabilidade: true,
          temDividasBancarias: false,
          temDividasImpostos: false,
          score: 100,
          limiteEstimado: 720000,
          tier: 'Tier A',
          status: 'Aprovado',
          dataSimulacao: '2026-06-30T10:00:00',
          afiliadoId: 'user-bronze',
          comissaoEstimada: 12000,
          regiao: 'São Paulo - SP'
        },
        {
          id: 'lead-2',
          empresa: 'Metalúrgica Vulcan',
          cnpj: '98.765.432/0001-21',
          adminNome: 'Roberto Souza',
          generoAdmin: 'Homem',
          faturamentoAnual: 2400000,
          tempoConstituicao: 48,
          possuiContabilidade: true,
          temDividasBancarias: true,
          temDividasImpostos: true,
          score: 30, // 100 - 30 (banco) - 40 (impostos) = 30
          limiteEstimado: 1200000,
          tier: 'Tier B',
          status: 'Limpeza de Nome Ativada',
          dataSimulacao: '2026-06-30T11:30:00',
          afiliadoId: 'user-prata',
          comissaoEstimada: 36000,
          regiao: 'Curitiba - PR'
        },
        {
          id: 'lead-3',
          empresa: 'Comércio de Doces do Vale',
          cnpj: '45.123.789/0001-55',
          adminNome: 'Claudio Antunes',
          generoAdmin: 'Homem',
          faturamentoAnual: 300000,
          tempoConstituicao: 8, // < 12 meses
          possuiContabilidade: true,
          temDividasBancarias: false,
          temDividasImpostos: false,
          score: 100,
          limiteEstimado: 150000,
          tier: 'Inapto',
          status: 'Simulado',
          dataSimulacao: '2026-06-30T14:15:00',
          afiliadoId: 'user-bronze',
          comissaoEstimada: 0,
          regiao: 'Salvador - BA'
        },
        {
          id: 'lead-4',
          empresa: 'Agropecuária Cerrado Verde',
          cnpj: '33.999.888/0001-44',
          adminNome: 'Beatriz Vasconcelos',
          generoAdmin: 'Mulher',
          faturamentoAnual: 4500000,
          tempoConstituicao: 60,
          possuiContabilidade: false,
          temDividasBancarias: true,
          temDividasImpostos: false,
          score: 70, // 100 - 30 = 70
          limiteEstimado: 2700000,
          tier: 'Tier B',
          status: 'Documentação Pendente',
          dataSimulacao: '2026-06-30T16:00:00',
          afiliadoId: 'user-ouro',
          comissaoEstimada: 81000,
          regiao: 'Goiânia - GO'
        }
      ];
      setLeads(defaultLeads);
      localStorage.setItem('gsa_credito_leads', JSON.stringify(defaultLeads));
    }

    if (savedConfig) {
      setComissaoConfig(JSON.parse(savedConfig));
    }
  }, []);

  const saveLeadsToStorage = (updated: CreditoLead[]) => {
    setLeads(updated);
    localStorage.setItem('gsa_credito_leads', JSON.stringify(updated));
  };

  // 4. Lógica de cálculo do Score e Limite de Crédito
  const calcularSimulacao = () => {
    // Limite Estimado: Homem 50%, Mulher 60% do faturamento anual
    const coeficiente = simGenero === 'Mulher' ? 0.60 : 0.50;
    const limiteEstimado = simFaturamento * coeficiente;

    // Tempo menor que 12 meses -> Inapto
    if (simTempo < 12) {
      return {
        score: 100,
        limiteEstimado,
        tier: 'Inapto' as const,
        status: 'Simulado' as const
      };
    }

    // Começa com 100 pontos
    let score = 100;
    if (simDividasBancarias) score -= 30;
    if (simDividasImpostos) score -= 40;

    // Determina o tier
    const tier = (simDividasBancarias || simDividasImpostos) ? 'Tier B' : 'Tier A';

    return {
      score,
      limiteEstimado,
      tier,
      status: (tier === 'Tier B' ? 'Documentação Pendente' : 'Simulado') as any
    };
  };

  const handleNovaSimulacao = (e: React.FormEvent) => {
    e.preventDefault();
    if (!simEmpresa || !simCnpj || !simAdminNome) {
      alert('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    const calculos = calcularSimulacao();
    const novoLead: CreditoLead = {
      id: 'lead-' + Date.now(),
      empresa: simEmpresa,
      cnpj: simCnpj,
      adminNome: simAdminNome,
      generoAdmin: simGenero,
      faturamentoAnual: simFaturamento,
      tempoConstituicao: simTempo,
      possuiContabilidade: simContabilidade,
      temDividasBancarias: simDividasBancarias,
      temDividasImpostos: simDividasImpostos,
      score: calculos.score,
      limiteEstimado: calculos.limiteEstimado,
      tier: calculos.tier,
      status: calculos.status,
      dataSimulacao: new Date().toISOString(),
      regiao: 'São Paulo - SP',
      afiliadoId: 'user-teste',
      comissaoEstimada: calculos.limiteEstimado * 0.03 // Estimando 3% de split da captação
    };

    const atualizados = [novoLead, ...leads];
    saveLeadsToStorage(atualizados);
    setShowSimuladorModal(false);

    // Limpar campos
    setSimEmpresa('');
    setSimCnpj('');
    setSimAdminNome('');
    setSimFaturamento(500000);
    setSimTempo(24);
    setSimContabilidade(true);
    setSimDividasBancarias(false);
    setSimDividasImpostos(false);

    // Se for Tier B, abre as opções jurídicas automaticamente
    if (novoLead.tier === 'Tier B') {
      setShowReabModal(novoLead);
    }
  };

  // Alterar Status do Lead (Simula fluxo comercial)
  const alterarStatusLead = (id: string, novoStatus: any) => {
    const atualizados = leads.map(l => {
      if (l.id === id) {
        return { ...l, status: novoStatus };
      }
      return l;
    });
    saveLeadsToStorage(atualizados);
  };

  // Excluir Lead
  const excluirLead = (id: string) => {
    if (confirm('Tem certeza de que deseja remover este lead?')) {
      const atualizados = leads.filter(l => l.id !== id);
      saveLeadsToStorage(atualizados);
    }
  };

  // Copiar links de indicação do Kit de Transmissão
  const handleCopiarLink = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiadoId(id);
    setTimeout(() => setCopiadoId(null), 2000);
  };

  // Filtros de busca
  const leadsFiltrados = leads.filter(l => 
    l.empresa.toLowerCase().includes(searchTerm.toLowerCase()) ||
    l.cnpj.includes(searchTerm) ||
    l.adminNome.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="space-y-8 animate-in fade-in duration-500 text-gray-900 pb-16">
      
      {/* HEADER DE TÍTULO DA FUNCIONALIDADE */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 md:p-8 rounded-3xl border border-gray-100 shadow-sm">
        <div>
          <div className="flex items-center gap-2.5 mb-2">
            <span className="px-3 py-1 bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold text-[10px] rounded-full uppercase tracking-widest">
              LegalTech & Fintech
            </span>
            <span className="px-3 py-1 bg-green-50 border border-green-100 text-green-600 font-bold text-[10px] rounded-full uppercase tracking-widest flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-ping" /> ATIVO
            </span>
          </div>
          <h1 className="text-3xl font-serif font-black tracking-tight text-gray-900 flex items-center gap-2">
            <BrainCircuit className="text-indigo-600 w-8 h-8" />
            Captação de Recursos & Crédito Inteligente
          </h1>
          <p className="text-gray-500 font-medium text-sm mt-1">
            Sistema integrado de análise de limites, MLM, crédito estruturado privado e reabilitação fiscal/judicial.
          </p>
        </div>

        <button
          onClick={() => setShowSimuladorModal(true)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm px-6 py-3.5 rounded-2xl flex items-center gap-2 shadow-lg shadow-indigo-500/10 cursor-pointer transition-all active:scale-95"
        >
          <Plus className="w-4 h-4" /> Nova Simulação de Crédito
        </button>
      </div>

      {/* SELETOR DE PERFIL PARA EXPERIÊNCIA DE TESTE MULTINÍVEL */}
      <div className="bg-slate-950 text-white p-5 rounded-3xl border border-slate-800 shadow-xl">
        <div className="flex flex-col lg:flex-row justify-between lg:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-600/20 text-indigo-400 rounded-xl border border-indigo-500/10">
              <ShieldAlert className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-sm">Matriz de Acessos por Nível Hierárquico (Simulação)</h4>
              <p className="text-xs text-slate-400">Alterne entre os níveis de perfil para verificar as visões e regras específicas do ecossistema GSA.</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'MASTER', label: '👑 GSA Master', color: 'bg-indigo-600' },
              { id: 'UNIDADE', label: '🏢 Unidade/Franquia', color: 'bg-emerald-600' },
              { id: 'ADVOGADO', label: '⚖️ Marina Stein (Adv)', color: 'bg-amber-600' },
              { id: 'VENDEDOR', label: '💼 Vendedor CRM', color: 'bg-blue-600' },
              { id: 'AFILIADO', label: '🔗 Afiliado MLM', color: 'bg-rose-600' },
            ].map(r => (
              <button
                key={r.id}
                onClick={() => setSelectedRole(r.id as any)}
                className={`text-xs font-bold px-4 py-2.5 rounded-xl transition-all cursor-pointer flex items-center gap-2 ${
                  selectedRole === r.id 
                    ? `${r.color} text-white shadow-lg` 
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                }`}
              >
                <span className={`w-1.5 h-1.5 rounded-full ${selectedRole === r.id ? 'bg-white' : 'bg-slate-500'}`} />
                {r.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* 1. VISÃO ADMIN MASTER                                    */}
      {/* ========================================================= */}
      {selectedRole === 'MASTER' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          
          {/* Métricas GSA Master */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Vol. Simulado Total</span>
                <span className="text-2xl font-serif font-black text-slate-900">
                  R$ {leads.reduce((acc, l) => acc + l.limiteEstimado, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[10px] text-indigo-500 font-bold block mt-1">Ancoragem Inteligente Ativa ⚡</span>
              </div>
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><BrainCircuit className="w-6 h-6" /></div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Linha Liberada (Pública)</span>
                <span className="text-2xl font-serif font-black text-emerald-600">
                  R$ {leads.filter(l => l.status === 'Aprovado' || l.status === 'Pago').reduce((acc, l) => acc + l.limiteEstimado, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[10px] text-slate-400 font-medium block mt-1">Garantias e Pronampe</span>
              </div>
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><CheckCircle className="w-6 h-6" /></div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">FIDC & Crédito Privado (Bridge)</span>
                <span className="text-2xl font-serif font-black text-indigo-900">
                  R$ {leads.filter(l => l.tier === 'Tier B').reduce((acc, l) => acc + l.limiteEstimado, 0).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                </span>
                <span className="text-[10px] text-amber-500 font-bold block mt-1">Ativação Automática Bridge</span>
              </div>
              <div className="p-3 bg-indigo-50 text-indigo-900 rounded-2xl"><Zap className="w-6 h-6" /></div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex items-center justify-between">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Leads Qualificados (Ecossistema)</span>
                <span className="text-2xl font-serif font-black text-slate-900">
                  {leads.length} Cadastros
                </span>
                <span className="text-[10px] text-indigo-500 font-bold block mt-1">Comissões MLM Integradas</span>
              </div>
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><Users className="w-6 h-6" /></div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* CONFIGURADOR DE COMISSÕES MULTINÍVEL */}
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-6">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                <Percent className="text-indigo-600 w-5 h-5" />
                <h3 className="font-bold text-base text-gray-900">Configurador de Comissões & Override GSA</h3>
              </div>
              
              <p className="text-xs text-gray-500">Defina os repasses automáticos do split de crédito liberado para cada nível do Marketing Multinível (MLM).</p>
              
              <div className="space-y-5">
                {/* Bronze */}
                <div className="p-4 bg-orange-50/50 border border-orange-100/60 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs text-orange-800">Bronze (Cliente Indicador)</span>
                    <span className="text-xs font-mono font-black text-orange-600">{comissaoConfig.bronzeComissaoDireta}% Direta</span>
                  </div>
                  <input 
                    type="range" min="5" max="15" value={comissaoConfig.bronzeComissaoDireta}
                    onChange={(e) => setComissaoConfig({...comissaoConfig, bronzeComissaoDireta: Number(e.target.value)})}
                    className="w-full h-1.5 bg-orange-200 rounded-lg appearance-none cursor-pointer"
                  />
                  <div className="flex justify-between text-[10px] text-orange-500">
                    <span>Mín: 5%</span>
                    <span>Max: 15%</span>
                  </div>
                </div>

                {/* Prata */}
                <div className="p-4 bg-slate-50 border border-slate-200/60 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs text-slate-800">Prata (Afiliado Profissional)</span>
                    <div className="flex gap-2">
                      <span className="text-xs font-mono font-bold text-slate-600">{comissaoConfig.prataComissaoDireta}% Dir.</span>
                      <span className="text-xs font-mono font-bold text-indigo-600">+{comissaoConfig.prataOverride}% Over</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="range" min="10" max="18" value={comissaoConfig.prataComissaoDireta}
                      onChange={(e) => setComissaoConfig({...comissaoConfig, prataComissaoDireta: Number(e.target.value)})}
                      className="w-full h-1.5 bg-slate-300 rounded-lg appearance-none cursor-pointer"
                    />
                    <input 
                      type="range" min="1" max="4" value={comissaoConfig.prataOverride}
                      onChange={(e) => setComissaoConfig({...comissaoConfig, prataOverride: Number(e.target.value)})}
                      className="w-full h-1.5 bg-indigo-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>

                {/* Ouro */}
                <div className="p-4 bg-amber-50/50 border border-amber-100/60 rounded-2xl space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="font-bold text-xs text-amber-800">Ouro (Líder / Unidade)</span>
                    <div className="flex gap-2">
                      <span className="text-xs font-mono font-bold text-amber-600">{comissaoConfig.ouroComissaoDireta}% Dir.</span>
                      <span className="text-xs font-mono font-bold text-indigo-600">+{comissaoConfig.ouroOverride}% Over</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <input 
                      type="range" min="15" max="25" value={comissaoConfig.ouroComissaoDireta}
                      onChange={(e) => setComissaoConfig({...comissaoConfig, ouroComissaoDireta: Number(e.target.value)})}
                      className="w-full h-1.5 bg-amber-300 rounded-lg appearance-none cursor-pointer"
                    />
                    <input 
                      type="range" min="2" max="8" value={comissaoConfig.ouroOverride}
                      onChange={(e) => setComissaoConfig({...comissaoConfig, ouroOverride: Number(e.target.value)})}
                      className="w-full h-1.5 bg-indigo-200 rounded-lg appearance-none cursor-pointer"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* MARKETPLACE DE PARCEIROS HOMOLOGADOS */}
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4 lg:col-span-2">
              <div className="flex justify-between items-center border-b border-gray-100 pb-4">
                <div className="flex items-center gap-2">
                  <Store className="text-indigo-600 w-5 h-5" />
                  <h3 className="font-bold text-base text-gray-900">Marketplace de Parceiros (Crédito Privado & Contábil)</h3>
                </div>
                <span className="px-2.5 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-black rounded-full uppercase">
                  5 Parceiros
                </span>
              </div>

              <p className="text-xs text-gray-500">Fundos de investimento (FIDCs) credenciados e escritórios de contabilidade parceiros para receber os leads que necessitam de estruturação contábil ou limpeza tributária.</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-2">
                
                {/* Parceiro FIDC */}
                <div className="p-4 border border-gray-100 rounded-2xl bg-slate-50/50 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[9px] font-bold rounded-md">FIDC Privado</span>
                      <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold">
                        <Check className="w-3.5 h-3.5" /> Homologado
                      </span>
                    </div>
                    <h5 className="font-bold text-xs text-gray-800">Apex Fundo de Crédito Estruturado</h5>
                    <p className="text-[10px] text-gray-500 mt-1">Taxas bridge a partir de 1.8% a.m. focado no mercado corporativo.</p>
                  </div>
                  <div className="flex justify-between items-center border-t border-gray-100 pt-3 mt-4">
                    <span className="text-[9px] text-gray-400">Linha Ativa: Bridge</span>
                    <button className="text-[10px] text-indigo-600 font-bold hover:underline cursor-pointer">Ver Relatório</button>
                  </div>
                </div>

                {/* Parceiro Contabilidade */}
                <div className="p-4 border border-gray-100 rounded-2xl bg-slate-50/50 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="px-2 py-0.5 bg-amber-50 text-amber-700 text-[9px] font-bold rounded-md">Contabilidade</span>
                      <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold">
                        <Check className="w-3.5 h-3.5" /> Ativo
                      </span>
                    </div>
                    <h5 className="font-bold text-xs text-gray-800">Conexão Contábil Associados</h5>
                    <p className="text-[10px] text-gray-500 mt-1">Especialistas em reestruturação fiscal e emissão ágil de CND da Receita.</p>
                  </div>
                  <div className="flex justify-between items-center border-t border-gray-100 pt-3 mt-4">
                    <span className="text-[9px] text-gray-400">Upsell Ativo: Receita Federal</span>
                    <button className="text-[10px] text-indigo-600 font-bold hover:underline cursor-pointer">Ver Contrato</button>
                  </div>
                </div>

                {/* Parceiro FIDC 2 */}
                <div className="p-4 border border-gray-100 rounded-2xl bg-slate-50/50 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[9px] font-bold rounded-md">FIDC Securitizadora</span>
                      <span className="flex items-center gap-1 text-[10px] text-emerald-600 font-bold">
                        <Check className="w-3.5 h-3.5" /> Homologado
                      </span>
                    </div>
                    <h5 className="font-bold text-xs text-gray-800">Horizon Securitizadora S/A</h5>
                    <p className="text-[10px] text-gray-500 mt-1">Especializada em desconto de duplicatas e crédito privado emergencial.</p>
                  </div>
                  <div className="flex justify-between items-center border-t border-gray-100 pt-3 mt-4">
                    <span className="text-[9px] text-gray-400">Linha Ativa: FIDC PME</span>
                    <button className="text-[10px] text-indigo-600 font-bold hover:underline cursor-pointer">Ver Taxas</button>
                  </div>
                </div>

                {/* Novo botão de Adicionar Parceiro */}
                <div className="p-4 border border-dashed border-gray-200 rounded-2xl flex flex-col justify-center items-center text-center cursor-pointer hover:bg-slate-50/40 transition-colors">
                  <Plus className="w-6 h-6 text-indigo-600 mb-1" />
                  <h5 className="font-bold text-xs text-slate-800">Adicionar Novo Parceiro</h5>
                  <p className="text-[10px] text-slate-400 max-w-xs mt-0.5">Credencie novos FIDCs ou escritórios contábeis.</p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================= */}
      {/* 2. VISÃO UNIDADE (FRANQUEADOS)                           */}
      {/* ========================================================= */}
      {selectedRole === 'UNIDADE' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
              <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Painel Regional (Seu Estado)</span>
              <h4 className="text-2xl font-serif font-black text-indigo-950 mt-1">Região Sul & PR</h4>
              <p className="text-xs text-slate-400 mt-2">Você gerencia os leads qualificados gerados no Paraná e Santa Catarina.</p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Volume Regional Analisado</span>
                <span className="text-xl font-serif font-black text-slate-900 block mt-1">R$ 4.250.000,00</span>
                <span className="text-[10px] text-emerald-500 font-bold block mt-1">Aproveitamento: 68%</span>
              </div>
              <div className="p-3 bg-indigo-50 text-indigo-600 rounded-2xl"><BarChart className="w-6 h-6" /></div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm flex justify-between items-center">
              <div>
                <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Repasses & Splits da Unidade</span>
                <span className="text-xl font-serif font-black text-emerald-600 block mt-1">R$ 85.000,00</span>
                <span className="text-[10px] text-slate-400 font-medium block mt-1">Split Regional Provisionado</span>
              </div>
              <div className="p-3 bg-emerald-50 text-emerald-600 rounded-2xl"><DollarSign className="w-6 h-6" /></div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="font-bold text-base text-gray-900 mb-4">Performance da Equipe Regional de Vendas</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-gray-100 text-gray-400 uppercase font-black text-[9px] tracking-widest bg-slate-50/50">
                    <th className="py-3 px-4">Vendedor</th>
                    <th className="py-3 px-4">Contatos WhatsApp (2h)</th>
                    <th className="py-3 px-4">Leads Convertidos</th>
                    <th className="py-3 px-4">Crédito Simulado</th>
                    <th className="py-3 px-4">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-800">Bruno Vendas GSA</td>
                    <td className="py-3 px-4">12 contatos rápidos</td>
                    <td className="py-3 px-4">4 Empresas (Tier A)</td>
                    <td className="py-3 px-4 font-mono">R$ 1.200.000,00</td>
                    <td className="py-3 px-4"><span className="px-2 py-0.5 bg-green-50 text-green-600 font-bold rounded-md">Meta Batida</span></td>
                  </tr>
                  <tr>
                    <td className="py-3 px-4 font-bold text-slate-800">Juliana Machado</td>
                    <td className="py-3 px-4">8 contatos rápidos</td>
                    <td className="py-3 px-4">2 Empresas (Tier B)</td>
                    <td className="py-3 px-4 font-mono">R$ 950.000,00</td>
                    <td className="py-3 px-4"><span className="px-2 py-0.5 bg-blue-50 text-blue-600 font-bold rounded-md">Em Progresso</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================= */}
      {/* 3. VISÃO ADVOGADO (MARINA STEIN / JURÍDICO)              */}
      {/* ========================================================= */}
      {selectedRole === 'ADVOGADO' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="bg-amber-50/50 border border-amber-200 p-5 rounded-3xl flex items-start gap-4">
            <div className="p-3 bg-amber-500/10 text-amber-700 rounded-2xl shrink-0">
              <Scale className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-sm text-amber-800">Fila de Análise Técnica Avançada (Tier B - Leads Restritos)</h4>
              <p className="text-xs text-amber-700 leading-relaxed mt-1">
                Abaixo estão listados os empresários que simularam crédito mas possuem restrições fiscais ou bancárias. O sistema gerou relatórios automáticos. Sua missão jurídica é reabilitar o CNPJ deles (emissão de contratos e relatórios abusivos) para o reingresso no crédito bancário.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {leads.filter(l => l.tier === 'Tier B').map(lead => (
              <div key={lead.id} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="px-2 py-0.5 bg-red-50 text-red-700 text-[10px] font-bold rounded-md uppercase">Tier B - Crítico</span>
                    <h4 className="font-bold text-sm mt-2 text-slate-800">{lead.empresa}</h4>
                    <p className="text-[10px] text-slate-400">{lead.cnpj}</p>
                  </div>
                  <div className="text-right">
                    <span className="text-[9px] text-slate-400 block font-bold">Faturamento</span>
                    <span className="font-mono font-black text-xs text-slate-700">R$ {lead.faturamentoAnual.toLocaleString('pt-BR')}</span>
                  </div>
                </div>

                <div className="p-3.5 bg-slate-50 border border-gray-100 rounded-2xl text-xs space-y-2">
                  <p className="font-bold text-[10px] text-slate-500 uppercase tracking-widest">Pendências Identificadas</p>
                  {lead.temDividasBancarias && (
                    <div className="flex items-center gap-1.5 text-red-600 font-medium">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Dívidas Bancárias / Comercial (Subtraiu 30 pts)</span>
                    </div>
                  )}
                  {lead.temDividasImpostos && (
                    <div className="flex items-center gap-1.5 text-red-600 font-medium">
                      <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                      <span>Dívidas Federais sem CND (Subtraiu 40 pts)</span>
                    </div>
                  )}
                  <div className="flex justify-between items-center border-t border-gray-100 pt-2 mt-2 font-bold text-slate-700 text-[11px]">
                    <span>Score de Preparação Atual:</span>
                    <span className="text-red-500 font-mono">{lead.score} / 100 Pontos</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => setShowReabModal(lead)}
                    className="flex-1 bg-amber-600 hover:bg-amber-500 text-white font-bold text-[11px] py-2.5 px-3 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-amber-500/10"
                  >
                    <FileText className="w-3.5 h-3.5" /> Emitir Contrato de Reabilitação
                  </button>
                  <button
                    onClick={() => setShowBridgeModal(lead)}
                    className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold text-[11px] py-2.5 px-4 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer border border-indigo-100"
                  >
                    <Zap className="w-3.5 h-3.5" /> Bridge FIDC
                  </button>
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      {/* ========================================================= */}
      {/* 4. VISÃO VENDEDOR (CRM ATIVO)                            */}
      {/* ========================================================= */}
      {selectedRole === 'VENDEDOR' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          <div className="bg-red-50/50 border border-red-100 p-4 rounded-3xl flex items-center gap-3">
            <div className="w-1.5 h-1.5 bg-red-500 rounded-full animate-ping shrink-0" />
            <p className="text-xs text-red-700 font-semibold">
              <strong className="text-red-800">ALERTA CRM ATIVO (Regra das 2h):</strong> Leads que geraram simulação e não enviaram documentação em 2 horas precisam de contato prioritário imediato.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex justify-between items-center border-b border-gray-100 pb-3">
              <h3 className="font-bold text-sm text-gray-800">Lista Ativa de Negociação prioritária</h3>
              <span className="text-[10px] bg-red-50 text-red-600 font-black rounded-full px-2.5 py-0.5">PRIORIDADE</span>
            </div>

            <div className="space-y-4">
              {leads.map(l => {
                const whatsText = `Olá ${l.adminNome}, tudo bem? Identifiquei aqui no sistema GSA Câmara que sua empresa ${l.empresa} tem um limite estimado de R$ ${l.limiteEstimado.toLocaleString('pt-BR')} disponível para captação. Vamos agilizar sua documentação hoje?`;
                const whatsUrl = `https://wa.me/5511999999999?text=${encodeURIComponent(whatsText)}`;

                return (
                  <div key={l.id} className="p-4 border border-gray-100 hover:border-gray-200 bg-slate-50/20 rounded-2xl flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-colors">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`w-2 h-2 rounded-full ${l.tier === 'Tier A' ? 'bg-green-500' : 'bg-red-500'}`} />
                        <h4 className="font-bold text-xs text-slate-800">{l.empresa}</h4>
                        <span className="text-[10px] text-slate-400 font-mono">({l.cnpj})</span>
                      </div>
                      <p className="text-[10px] text-slate-500">
                        Administrador: <strong className="text-slate-600">{l.adminNome}</strong> | Limite Estimado: <strong className="text-slate-600">R$ {l.limiteEstimado.toLocaleString('pt-BR')}</strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                        l.status === 'Aprovado' ? 'bg-emerald-50 text-emerald-700' :
                        l.status === 'Documentação Pendente' ? 'bg-red-50 text-red-600 animate-pulse' :
                        'bg-blue-50 text-blue-700'
                      }`}>
                        {l.status}
                      </span>
                      
                      <a
                        href={whatsUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-[10px] px-3.5 py-2 rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer"
                      >
                        <MessageSquare className="w-3.5 h-3.5" /> WhatsApp Rápido
                      </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      )}

      {/* ========================================================= */}
      {/* 5. VISÃO AFILIADO (MARKETING MULTINÍVEL / REDE)           */}
      {/* ========================================================= */}
      {selectedRole === 'AFILIADO' && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
          
          {/* Quadro de Classificação do Afiliado */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-gradient-to-br from-amber-50 to-orange-50 border border-amber-100 p-6 rounded-3xl relative overflow-hidden">
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Sparkles className="w-24 h-24 text-amber-500" />
              </div>
              <span className="px-2.5 py-0.5 bg-amber-500 text-white text-[9px] font-black rounded-full uppercase tracking-wider">
                Meu Ranking MLM
              </span>
              <h4 className="text-2xl font-serif font-black text-amber-800 mt-2">Nível Prata (Profissional)</h4>
              <p className="text-xs text-amber-700 mt-1">Faltam apenas 2 leads qualificados para subir para o nível Ouro!</p>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
              <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Membros na Rede</span>
              <span className="text-2xl font-serif font-black text-slate-800">14 Indicados diretos</span>
              <div className="flex justify-between items-center text-[10px] text-indigo-600 font-bold mt-2">
                <span>Override Ativo de 2% ⚡</span>
                <span className="underline cursor-pointer">Ver Árvore</span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
              <span className="text-gray-400 text-[10px] font-bold uppercase tracking-wider block mb-1">Comissão Acumulada</span>
              <span className="text-2xl font-serif font-black text-emerald-600">R$ 14.250,00</span>
              <div className="flex justify-between items-center text-[10px] text-slate-400 mt-2">
                <span>Disponível para saque</span>
                <button className="text-emerald-600 font-bold underline cursor-pointer">Sacar Agora</button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            
            {/* MINHA REDE & INDICAÇÕES */}
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
                <Activity className="text-rose-600 w-5 h-5" />
                <h3 className="font-bold text-sm text-gray-800">Progresso de Indicações (Visão Blindada)</h3>
              </div>
              
              <p className="text-xs text-gray-500">
                Acompanhe o andamento dos seus indicados sem exposição de dados sensíveis da empresa ou valores de contabilidade privada.
              </p>

              <div className="space-y-3">
                {[
                  { iniciais: 'E** X', status: 'Documentação Pendente', cor: 'bg-red-50 text-red-600', estimativa: 'R$ 12.450,00' },
                  { iniciais: 'M** S', status: 'Análise Técnica', cor: 'bg-indigo-50 text-indigo-600', estimativa: 'R$ 36.120,00' },
                  { iniciais: 'C** D', status: 'Aprovado', cor: 'bg-emerald-50 text-emerald-700', estimativa: 'R$ 45.000,00' }
                ].map((ind, idx) => (
                  <div key={idx} className="p-3.5 bg-slate-50/50 border border-gray-100 rounded-2xl flex justify-between items-center text-xs">
                    <div className="flex items-center gap-3">
                      <span className="w-8 h-8 rounded-full bg-slate-200 text-slate-700 font-black flex items-center justify-center text-[10px]">
                        {idx + 1}
                      </span>
                      <div>
                        <span className="font-bold text-slate-800 block">Empresa {ind.iniciais}</span>
                        <span className="text-[10px] text-slate-400">Origem: Seu Link de Indicação</span>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold block mb-1 ${ind.cor}`}>{ind.status}</span>
                      <span className="text-[10px] text-slate-500">Comissão Prevista: <strong className="text-emerald-600 font-mono">{ind.estimativa}</strong></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* KIT DE TRANSMISSÃO DINÂMICO */}
            <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
              <div className="flex items-center gap-2 border-b border-gray-100 pb-3">
                <Share2 className="text-rose-600 w-5 h-5" />
                <h3 className="font-bold text-sm text-gray-800">Kit de Transmissão & Links Rápidos</h3>
              </div>
              
              <p className="text-xs text-gray-500">
                Utilize seus links parametrizados com seu ID de afiliado para captar leads e automatizar a comissão na árvore multinível.
              </p>

              <div className="space-y-4 pt-2">
                
                {/* Link Principal */}
                <div className="p-4 bg-slate-50 border border-gray-100 rounded-2xl space-y-2">
                  <span className="font-bold text-slate-500 text-[10px] uppercase block tracking-wider">Seu Link de Captação Pública</span>
                  <div className="flex gap-2">
                    <input 
                      type="text" 
                      readOnly 
                      value="https://gsa-camara.com.br/solucoes?ref=atende_gsa" 
                      className="flex-1 bg-white border border-gray-200 text-xs text-slate-600 rounded-xl px-3 outline-none"
                    />
                    <button
                      onClick={() => handleCopiarLink('https://gsa-camara.com.br/solucoes?ref=atende_gsa', 'link-1')}
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs p-3 rounded-xl cursor-pointer flex items-center justify-center shrink-0"
                    >
                      {copiadoId === 'link-1' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Criativo Flyer de Marketing Dinâmico */}
                <div className="p-4 bg-slate-900 text-white rounded-2xl space-y-3 relative overflow-hidden">
                  <div className="absolute top-0 right-0 p-4 opacity-5">
                    <BrainCircuit className="w-24 h-24" />
                  </div>
                  <div>
                    <h5 className="font-black text-xs text-indigo-400 uppercase tracking-widest">Flyer Digital de Captação</h5>
                    <p className="text-[10px] text-slate-400 mt-1">Gere um card visual de propaganda com seus dados de contato automáticos para mandar no WhatsApp.</p>
                  </div>

                  <div className="border border-slate-800 bg-slate-950 p-3 rounded-xl space-y-1.5 text-center">
                    <span className="text-[11px] font-serif font-black text-slate-200 block">GSA CÂMARA DE CRÉDITO</span>
                    <p className="text-[10px] text-indigo-400 font-bold">R$ 50.000 a R$ 5.000.000 liberados para empresas!</p>
                    <div className="border-t border-slate-900 my-1 pt-1 text-[8px] text-slate-500">
                      Indicado por: atende.gsa@gmail.com | Contato Imediato
                    </div>
                  </div>

                  <button className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-[10px] py-2 rounded-xl flex items-center justify-center gap-1.5 cursor-pointer">
                    <Download className="w-3.5 h-3.5" /> Baixar Imagem / Criativo
                  </button>
                </div>

              </div>
            </div>

          </div>
        </motion.div>
      )}

      {/* ========================================================= */}
      {/* LISTA GERAL DE LEADS ATIVOS (PESQUISA / TABELA PRINCIPAL)  */}
      {/* ========================================================= */}
      <div className="bg-white rounded-3xl border border-gray-100 shadow-sm p-6 space-y-6">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h3 className="font-bold text-lg text-gray-900">Monitor de Leads Qualificados</h3>
            <p className="text-xs text-gray-500">Base centralizada de simulações, scores e classificação do ecossistema.</p>
          </div>
          
          <div className="w-full md:w-72">
            <input
              type="text"
              placeholder="Buscar por Empresa, CNPJ ou Nome..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full border border-gray-200 text-xs px-4 py-3 rounded-xl outline-none focus:border-indigo-500 transition-colors"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-gray-100 text-gray-400 uppercase font-black text-[9px] tracking-widest bg-slate-50/50">
                <th className="py-3 px-4">Empresa / CNPJ</th>
                <th className="py-3 px-4">Administrador / Gênero</th>
                <th className="py-3 px-4">Tempo</th>
                <th className="py-3 px-4">Faturamento Anual</th>
                <th className="py-3 px-4">Limite Estimado</th>
                <th className="py-3 px-4">Score / Classificação</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100 font-medium">
              {leadsFiltrados.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-gray-400 text-xs">Nenhum lead encontrado com estes filtros.</td>
                </tr>
              ) : (
                leadsFiltrados.map(lead => (
                  <tr key={lead.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-4">
                      <span className="font-bold text-slate-800 block text-xs">{lead.empresa}</span>
                      <span className="text-[10px] text-slate-400 font-mono">{lead.cnpj}</span>
                    </td>
                    <td className="py-4 px-4 text-slate-600">
                      <span className="block text-xs">{lead.adminNome}</span>
                      <span className="text-[9px] bg-slate-100 px-1.5 py-0.5 rounded text-slate-500">{lead.generoAdmin}</span>
                    </td>
                    <td className="py-4 px-4 font-mono text-slate-600">{lead.tempoConstituicao} Meses</td>
                    <td className="py-4 px-4 font-mono text-slate-600">
                      R$ {lead.faturamentoAnual.toLocaleString('pt-BR')}
                    </td>
                    <td className="py-4 px-4 font-mono font-bold text-indigo-600">
                      R$ {lead.limiteEstimado.toLocaleString('pt-BR')}
                    </td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-2.5 h-2.5 rounded-full ${lead.score >= 100 ? 'bg-green-500' : lead.score >= 50 ? 'bg-amber-500' : 'bg-red-500'}`} />
                        <span className="font-bold text-slate-700">{lead.score} pts</span>
                      </div>
                      <span className={`text-[9px] font-bold block mt-1 ${
                        lead.tier === 'Tier A' ? 'text-green-600' : lead.tier === 'Tier B' ? 'text-red-500' : 'text-slate-400'
                      }`}>
                        {lead.tier}
                      </span>
                    </td>
                    <td className="py-4 px-4">
                      <select
                        value={lead.status}
                        onChange={(e) => alterarStatusLead(lead.id, e.target.value as any)}
                        className="bg-slate-50 border border-gray-100 rounded px-2 py-1 text-[10px] font-bold outline-none cursor-pointer"
                      >
                        <option value="Simulado">Simulado</option>
                        <option value="Documentação Pendente">Documentação Pendente</option>
                        <option value="Análise Técnica">Análise Técnica</option>
                        <option value="Aprovado">Aprovado</option>
                        <option value="Pago">Pago</option>
                        <option value="Limpeza de Nome Ativada">Limpeza de Nome Ativada</option>
                      </select>
                    </td>
                    <td className="py-4 px-4 text-right space-x-1.5 whitespace-nowrap">
                      {lead.tier === 'Tier B' && (
                        <button
                          onClick={() => setShowReabModal(lead)}
                          title="Gerar Contrato de Reabilitação de Nome"
                          className="p-1.5 bg-amber-50 text-amber-700 hover:bg-amber-100 rounded-lg cursor-pointer inline-block"
                        >
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                      )}
                      <button
                        onClick={() => setShowBridgeModal(lead)}
                        title="Ver Ativação Bridge"
                        className="p-1.5 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 rounded-lg cursor-pointer inline-block"
                      >
                        <Zap className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => excluirLead(lead.id)}
                        className="p-1.5 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg cursor-pointer inline-block"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* ========================================================= */}
      {/* MODAL / SIMULADOR DE CRÉDITO INTERATIVO                  */}
      {/* ========================================================= */}
      {showSimuladorModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-[10000] animate-fade-in">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white border border-gray-100 rounded-3xl p-6 md:p-8 max-w-lg w-full shadow-2xl relative max-h-[90vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowSimuladorModal(false)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <XCircle className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-2 mb-6">
              <BrainCircuit className="text-indigo-600 w-6 h-6" />
              <h3 className="font-serif font-black text-xl text-gray-900">Simulador de Limite de Crédito</h3>
            </div>

            <form onSubmit={handleNovaSimulacao} className="space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-600 block">Nome da Empresa *</label>
                <input 
                  type="text" required placeholder="Ex: Alpha Tec Ltda"
                  value={simEmpresa} onChange={(e) => setSimEmpresa(e.target.value)}
                  className="w-full border border-gray-200 text-xs px-3 py-2.5 rounded-xl outline-none"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">CNPJ *</label>
                  <input 
                    type="text" required placeholder="Ex: 00.000.000/0001-00"
                    value={simCnpj} onChange={(e) => setSimCnpj(e.target.value)}
                    className="w-full border border-gray-200 text-xs px-3 py-2.5 rounded-xl outline-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">Nome do Administrador *</label>
                  <input 
                    type="text" required placeholder="Ex: Roberto Silva"
                    value={simAdminNome} onChange={(e) => setSimAdminNome(e.target.value)}
                    className="w-full border border-gray-200 text-xs px-3 py-2.5 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">Gênero do Administrador (Ancoragem) *</label>
                  <div className="flex gap-2">
                    {['Mulher', 'Homem'].map(g => (
                      <button
                        key={g} type="button"
                        onClick={() => setSimGenero(g as any)}
                        className={`flex-1 text-xs font-bold py-2 px-3 rounded-xl border transition-colors cursor-pointer ${
                          simGenero === g 
                            ? 'bg-indigo-600 text-white border-indigo-600' 
                            : 'border-gray-200 text-gray-500 hover:bg-slate-50'
                        }`}
                      >
                        {g} {g === 'Mulher' ? '(Coeficiente 0.60)' : '(Coeficiente 0.50)'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">Faturamento Anual (R$) *</label>
                  <input 
                    type="number" required placeholder="Ex: 1200000"
                    value={simFaturamento} onChange={(e) => setSimFaturamento(Number(e.target.value))}
                    className="w-full border border-gray-200 text-xs px-3 py-2.5 rounded-xl outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">Tempo de Constituição (Meses) *</label>
                  <input 
                    type="number" required placeholder="Ex: 24"
                    value={simTempo} onChange={(e) => setSimTempo(Number(e.target.value))}
                    className="w-full border border-gray-200 text-xs px-3 py-2.5 rounded-xl outline-none"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-gray-600 block">Contabilidade Homologada?</label>
                  <div className="flex gap-2">
                    {[true, false].map(v => (
                      <button
                        key={v ? 'sim' : 'nao'} type="button"
                        onClick={() => setSimContabilidade(v)}
                        className={`flex-1 text-xs font-bold py-2 px-3 rounded-xl border transition-colors cursor-pointer ${
                          simContabilidade === v 
                            ? 'bg-indigo-600 text-white border-indigo-600' 
                            : 'border-gray-200 text-gray-500 hover:bg-slate-50'
                        }`}
                      >
                        {v ? 'Sim' : 'Não'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-gray-100 rounded-2xl space-y-3">
                <p className="font-bold text-[10px] text-slate-500 uppercase tracking-widest">Análise de Restrições Empresariais (Filtros de Score)</p>
                
                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input 
                    type="checkbox" checked={simDividasBancarias} 
                    onChange={(e) => setSimDividasBancarias(e.target.checked)}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Dívidas Bancárias ou Restrição Comercial (Subtrai 30 pontos)</span>
                </label>

                <label className="flex items-center gap-2 text-xs text-slate-700 cursor-pointer">
                  <input 
                    type="checkbox" checked={simDividasImpostos} 
                    onChange={(e) => setSimDividasImpostos(e.target.checked)}
                    className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Dívidas de Impostos / Receita Federal sem CND (Subtrai 40 pontos)</span>
                </label>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-3.5 rounded-xl cursor-pointer shadow-lg shadow-indigo-500/10 transition-all text-center block"
              >
                Gerar Limite & Registrar Lead
              </button>
            </form>
          </motion.div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL DE EMISSÃO DE CONTRATO DE REABILITAÇÃO (ADVOGADO) */}
      {/* ========================================================= */}
      {showReabModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-[10000] animate-fade-in">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white border border-gray-100 rounded-3xl p-6 md:p-8 max-w-2xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowReabModal(null)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <XCircle className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Scale className="text-amber-600 w-6 h-6" />
              <h3 className="font-serif font-black text-xl text-gray-900">Contrato de Reabilitação Judicial de Nome</h3>
            </div>

            <p className="text-xs text-slate-500 mb-6">
              Emissão automática pela GSA Soluções de reabilitação. O contrato abaixo foi gerado dinamicamente com base nas dívidas bancárias e restrições fiscais detectadas no score.
            </p>

            <div className="p-6 bg-slate-50 border border-gray-200 rounded-2xl font-mono text-[10px] text-slate-700 space-y-4 max-h-96 overflow-y-auto custom-scrollbar leading-relaxed">
              <div className="text-center font-bold text-slate-800 border-b border-gray-200 pb-3 mb-3">
                CONTRATO DE PRESTAÇÃO DE SERVIÇOS JURÍDICOS E REABILITAÇÃO EXTRAJUDICIAL
              </div>
              
              <p>
                <strong>CONTRATANTE:</strong> {showReabModal.empresa}, CNPJ nº {showReabModal.cnpj}, representada neste ato por seu administrador, {showReabModal.adminNome}.
              </p>
              
              <p>
                <strong>CONTRATADA:</strong> GSA CÂMARA DE MEDIAÇÃO, CONCILIAÇÃO E ARBITRAGEM S/A, com sede em Curitiba/PR.
              </p>

              <p>
                <strong>CLÁUSULA PRIMEIRA - OBJETO:</strong> O objeto deste contrato é a prestação de serviços extrajudiciais e judiciais visando a reabilitação de crédito da CONTRATANTE, com a baixa ou suspensão de apontamentos restritivos decorrentes de dívidas bancárias registradas, com base na abusividade na cobrança fiscal verificada por este sistema (Score: {showReabModal.score}/100).
              </p>

              <p>
                <strong>CLÁUSULA SEGUNDA - HONORÁRIOS:</strong> Pelos serviços acordados, a CONTRATANTE pagará à CONTRATADA a importância equivalente a 5% (cinco por cento) sobre o limite de crédito reabilitado de R$ {showReabModal.limiteEstimado.toLocaleString('pt-BR')}, além de custos operacionais cartorários previstos em tabela de custas.
              </p>

              <p>
                <strong>CLÁUSULA TERCEIRA - MULTINÍVEL E REPASSES:</strong> Os honorários pagos pela contratante serão passíveis de split automático do ecossistema, com comissão direta destinada ao afiliado originador e bônus de override estipulado para a Unidade Regional homologada.
              </p>

              <div className="border-t border-gray-200 pt-4 mt-4 text-center text-slate-400">
                Documento gerado digitalmente em {new Date(showReabModal.dataSimulacao).toLocaleDateString('pt-BR')} por Marina Stein.
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  alert('Contrato assinado e enviado com sucesso ao cliente via WhatsApp/E-mail!');
                  setShowReabModal(null);
                }}
                className="flex-1 bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs py-3 rounded-xl transition-colors cursor-pointer text-center"
              >
                Confirmar Assinatura & Enviar Cliente
              </button>
              <button
                onClick={() => handleCopiarLink('Contrato de Reabilitação GSA Soluções', 'contrato-copia')}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-3 px-6 rounded-xl transition-colors cursor-pointer"
              >
                {copiadoId === 'contrato-copia' ? 'Copiado!' : 'Copiar Texto'}
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL DA PONTE BRIDGE DE CRÉDITO PRIVADO (FIDCs)        */}
      {/* ========================================================= */}
      {showBridgeModal && (
        <div className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4 z-[10000] animate-fade-in">
          <motion.div 
            initial={{ scale: 0.95, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }} 
            className="bg-white border border-gray-100 rounded-3xl p-6 md:p-8 max-w-xl w-full shadow-2xl relative max-h-[90vh] overflow-y-auto"
          >
            <button 
              onClick={() => setShowBridgeModal(null)}
              className="absolute top-5 right-5 text-gray-400 hover:text-gray-600 cursor-pointer"
            >
              <XCircle className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-2 mb-4">
              <Zap className="text-indigo-600 w-6 h-6" />
              <h3 className="font-serif font-black text-xl text-gray-900">Mecanismo Bridge: Crédito Privado FIDC</h3>
            </div>

            <p className="text-xs text-slate-500 mb-6">
              Como o cliente possui restrições severas, as linhas públicas tradicionais foram temporariamente bloqueadas. O sistema ativou automaticamente o **Mecanismo Bridge** encaminhando para nossos fundos privados credenciados.
            </p>

            <div className="space-y-4">
              <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl space-y-3">
                <div className="flex justify-between items-center border-b border-indigo-200/50 pb-2">
                  <span className="font-bold text-xs text-indigo-900">Apex Crédito Privado FIDC</span>
                  <span className="text-[10px] bg-indigo-100 text-indigo-700 font-black rounded px-2">EM ANÁLISE BRIDGE</span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px]">Limite Solicitado</span>
                    <strong className="text-slate-700 font-mono">R$ {showBridgeModal.limiteEstimado.toLocaleString('pt-BR')}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">Taxa Estrutural</span>
                    <strong className="text-emerald-600 font-mono">1.85% a.m.</strong>
                  </div>
                </div>

                <div className="p-2.5 bg-white rounded-xl border border-indigo-200/30 text-[11px] text-indigo-800 leading-relaxed">
                  📢 <strong>Status Bridge:</strong> Apex FIDC analisou a saúde de recebíveis e aceitou o risco sob a condição de reabilitação jurídica de nome em andamento pela Marina Stein GSA.
                </div>
              </div>

              <div className="border border-dashed border-gray-200 p-4 rounded-2xl flex justify-between items-center text-xs">
                <div>
                  <span className="font-bold text-slate-800 block">Comissão Split MLM Provisionada</span>
                  <span className="text-[10px] text-slate-400">Total rateado na rede: 2.5%</span>
                </div>
                <strong className="text-emerald-600 font-mono">R$ {(showBridgeModal.limiteEstimado * 0.025).toLocaleString('pt-BR')}</strong>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  alert('Proposta do FIDC Apex enviada ao empresário para assinatura eletrônica!');
                  setShowBridgeModal(null);
                }}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs py-3 rounded-xl transition-colors cursor-pointer text-center"
              >
                Enviar Proposta do FIDC Apex ao Cliente
              </button>
              <button
                onClick={() => setShowBridgeModal(null)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-3 px-6 rounded-xl transition-colors cursor-pointer"
              >
                Voltar
              </button>
            </div>
          </motion.div>
        </div>
      )}

    </div>
  );
}
