import React, { useState, useEffect } from 'react';
import { Download, X } from 'lucide-react';

export const PwaInstallBanner: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    // Captura o evento nativo de instalação do Android/Chrome
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setShowBanner(true);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    // Monitora se o app já foi instalado
    const handleAppInstalled = () => {
      console.log('✨ GSA Câmara instalado com sucesso na tela inicial.');
      setShowBanner(false);
    };

    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    
    // Exibe o prompt nativo do sistema operacional
    deferredPrompt.prompt();
    
    // Aguarda a resposta do usuário
    const choiceResult = await deferredPrompt.userChoice;
    console.log(`Usuário escolheu: ${choiceResult.outcome}`);
    
    setDeferredPrompt(null);
    setShowBanner(false);
  };

  if (!showBanner) return null;

  return (
    <div id="pwa-install-banner" className="fixed bottom-4 left-4 right-4 md:left-auto md:right-4 md:w-96 bg-slate-950 text-white p-5 rounded-2xl shadow-2xl border border-slate-800 z-[9999] animate-bounce-short">
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <Download className="w-5 h-5 text-white" />
          </div>
          <div>
            <h4 className="font-bold text-sm text-slate-100">Instalar Aplicativo Oficial</h4>
            <p className="text-xs text-slate-400">Acesse a GSA Câmara direto da sua tela inicial.</p>
          </div>
        </div>
        <button onClick={() => setShowBanner(false)} className="text-slate-500 hover:text-slate-300 cursor-pointer">
          <X className="w-4 h-4" />
        </button>
      </div>
      
      <p className="text-xs text-slate-300 mb-4">
        Receba alertas de andamentos, notificações de acordos e avisos sonoros em tempo real no seu aparelho.
      </p>
      
      <div className="flex gap-2">
        <button
          onClick={handleInstallClick}
          className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold py-2.5 px-4 rounded-xl transition-colors flex items-center justify-center gap-2 cursor-pointer"
        >
          <Download className="w-4 h-4" /> Baixar App
        </button>
        <button
          onClick={() => setShowBanner(false)}
          className="bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-medium py-2.5 px-4 rounded-xl transition-colors cursor-pointer"
        >
          Depois
        </button>
      </div>
    </div>
  );
};
