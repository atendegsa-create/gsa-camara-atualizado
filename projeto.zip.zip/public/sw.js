// Escuta os eventos de Notificação Push vindos do Backend da GSA
self.addEventListener('push', function(event) {
  let data = { title: 'GSA Câmara', body: 'Nova atualização disponível.' };
  
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'GSA Câmara', body: event.data.text() };
    }
  }

  const options = {
    body: data.body,
    icon: '/icon-192.png',
    badge: '/icon-192.png',
    
    // Configurações de som e feedback físico do aparelho
    sound: '/sounds/notification.mp3', // Caminho do áudio carregado na pasta public
    vibrate: [200, 100, 200, 100, 200], // Padrão de vibração: vibra, para, vibra, para...
    
    // Garante que a notificação apareça como prioridade alta no sistema operacional
    tag: data.tag || 'gsa-alert-default',
    renotify: true, // Substitui notificações com a mesma tag alertando o usuário
    requireInteraction: true, // Mantém o alerta na tela do celular até que o usuário clique ou limpe
    
    data: {
      url: data.url || '/'
    }
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

// Abre o aplicativo na tela correta quando o cliente clica na notificação
self.addEventListener('notificationclick', function(event) {
  event.notification.close();
  event.waitUntil(
    clients.openWindow(event.notification.data.url)
  );
});
